# azDevOps-sprint-report

Built in Azure DevOps for Azure DevOps

[![Build status](https://oneluckidev.visualstudio.com/OneLuckiDev/_apis/build/status/azDevOps-sprint-report)](https://oneluckidev.visualstudio.com/OneLuckiDev/_build/latest?definitionId=24)